$(document).ready(function () {
    
    $("#test_button").on('click', function() {
        alert('button works')
    })
    
    
    
})









